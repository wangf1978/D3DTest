#pragma once

#include <d3d9.h>
#include <opmapi.h>
#include <wrl/client.h>
#include "CryptUtil.h"

using namespace Microsoft::WRL;

FLAG_NAME_PAIRW OPM_STATUS_flag_names[] = {
	DECL_TUPLE_W(OPM_STATUS_LINK_LOST),
	DECL_TUPLE_W(OPM_STATUS_RENEGOTIATION_REQUIRED),
	DECL_TUPLE_W(OPM_STATUS_TAMPERING_DETECTED),
	DECL_TUPLE_W(OPM_STATUS_REVOKED_HDCP_DEVICE_ATTACHED),
};

FLAG_NAME_PAIRW OPM_PROTECTION_TYPE_flag_names[] = {
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_OTHER),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_COPP_COMPATIBLE_HDCP),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_ACP),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_CGMSA),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_HDCP),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_DPCP),
	DECL_TUPLE_W(OPM_PROTECTION_TYPE_TYPE_ENFORCEMENT_HDCP)
};

class COPMSession
{
public:
	COPMSession(IOPMVideoOutput* pOPMVideoOutput, HRESULT* phr=nullptr);
	virtual ~COPMSession();

	/*
	OPM_GET_CURRENT_HDCP_SRM_VERSION,
	OPM_GET_CONNECTED_HDCP_DEVICE_INFORMATION,
	OPM_GET_ACP_AND_CGMSA_SIGNALING,
	OPM_GET_CONNECTOR_TYPE,
	OPM_GET_SUPPORTED_PROTECTION_TYPES,
	OPM_GET_VIRTUAL_PROTECTION_LEVEL,
	OPM_GET_ACTUAL_PROTECTION_LEVEL,
	OPM_GET_ACTUAL_OUTPUT_FORMAT,
	OPM_GET_ADAPTER_BUS_TYPE,
	OPM_GET_OUTPUT_ID,
	OPM_GET_DVI_CHARACTERISTICS,
	OPM_GET_CODEC_INFO,
	OPM_GET_OUTPUT_HARDWARE_PROTECTION_SUPPORT
	OPM_SET_PROTECTION_LEVEL,
	OPM_SET_ACP_AND_CGMSA_SIGNALING,
	OPM_SET_HDCP_SRM,
	OPM_SET_PROTECTION_LEVEL_ACCORDING_TO_CSS_DVD
	*/

	HRESULT GetCurrentHDCPSRMVersion(ULONG& HDCPSRMVer, ULONG* pulStatusFlags = NULL);
	HRESULT GetConnectedHDCPDeviceInformation(ULONG& ulHDCPFlags, OPM_HDCP_KEY_SELECTION_VECTOR& HDCP_Key_Selection_Vector, ULONG* pulStatusFlags = NULL);
	HRESULT GetACPAndCGMSASignaling(OPM_ACP_AND_CGMSA_SIGNALING& signaling);
	HRESULT GetConnectorType(ULONG& ulConnectorType, ULONG* pulStatusFlags = NULL);
	HRESULT GetSupportedProtectionTypes(ULONG& ulProtectionTypes, ULONG* pulStatusFlags = NULL);
	HRESULT GetVirtualProtectionLevel(ULONG protection_type, ULONG& protection_level, ULONG* pulStatusFlags = NULL);
	HRESULT GetActualProtectionLevel(ULONG protection_type, ULONG& protection_level, ULONG* pulStatusFlags = NULL);
	HRESULT GetActualOutputFormat(OPM_ACTUAL_OUTPUT_FORMAT& output_format);
	HRESULT GetAdaptorBusType(ULONG& ulBusType, ULONG* pulStatusFlags = NULL);
	HRESULT GetOutputID(UINT64& ullOutputID, ULONG* pulStatusFlags = NULL);
	HRESULT GetDVICharacteristics(ULONG& ulCharacteristics, ULONG* pulStatusFlags = NULL);
	HRESULT GetCodecInfo(DWORD& Merit, ULONG* pulStatusFlags = NULL);
	HRESULT GetOutputHardwareProtectionSupport(OPM_OUTPUT_HARDWARE_PROTECTION& eSupportState, ULONG* pulStatusFlags = NULL);
	HRESULT GetProtectionLevel(ULONG* ulStatusFlags = NULL);

	HRESULT SetProtectionLevel(ULONG ulProtectionType, ULONG ulProtectionLevel);
	HRESULT SetHDCPSRM(ULONG ulSRMVersion, uint8_t* pSRMData, size_t cbSRMData);
	HRESULT SetACPAndCGMSASignaling(OPM_SET_ACP_AND_CGMSA_SIGNALING_PARAMETERS params);
	HRESULT SetProtectionLevelAccordingToCSSDVD(ULONG ulProtectionType, ULONG ulProtectionLevel);

private:
	HRESULT _StatusRequest(GUID guidInformation, OPM_REQUESTED_INFORMATION& request_info, uint8_t* pParams=NULL, size_t cbParams=0);

protected:
	ComPtr<IOPMVideoOutput>			m_spOPMVideoOutput;
	OPM_RANDOM_NUMBER				m_keySession;

	ULONG							m_ulStatusSequence;
};


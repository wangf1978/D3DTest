#include "stdafx.h"
#include <initguid.h>
#include "OPMSession.h"

/*! @brief  Public key for trusted root certificates
*
*  Writing an Input Trust Authority defined in
*/
const BYTE PETRUSTED_ROOTCERT_PUBKEY[] = {
	0x30,0x82,0x02,0x0a,0x02,0x82,0x02,0x01,0x00,0xbc,0xfd,0x36,0xd3,0x2f,0x1c,0x7c,
	0xba,0xc6,0x04,0x58,0xf2,0xab,0x30,0xa3,0xf1,0x7d,0xd4,0xb9,0x83,0xef,0x72,0xdb,
	0x00,0x9c,0xcf,0xe6,0x5f,0x0c,0xf1,0x44,0xbe,0x62,0x22,0x5d,0x2f,0x77,0x50,0x7c,
	0xd6,0x85,0x39,0xfe,0x7a,0xae,0x99,0x1e,0xc8,0xb3,0xf9,0xc7,0x3c,0xc0,0x22,0x8d,
	0xc7,0xa7,0xf9,0xed,0x87,0xe8,0x41,0xac,0xe4,0x2d,0xf2,0x80,0x4e,0x14,0x8b,0xb4,
	0xf5,0x25,0x0b,0x94,0x8d,0x6f,0xb4,0x29,0x82,0xcf,0xe6,0x9e,0xfd,0xf7,0x9f,0xe5,
	0xb8,0x28,0xb7,0x36,0x6b,0x2f,0x6d,0x00,0xa4,0x49,0xbf,0x78,0x81,0x4f,0xa8,0x06,
	0x94,0x33,0xd0,0xd5,0x57,0x20,0xa8,0x72,0x8b,0xfe,0xd7,0xf5,0x63,0x2c,0x8d,0x44,
	0xe9,0x60,0xfe,0x2f,0xf5,0x39,0xb6,0x25,0x06,0x9e,0x04,0xc3,0x4d,0x95,0x2e,0xd5,
	0x22,0x05,0x30,0x4a,0x41,0x22,0x61,0x0d,0x5a,0x24,0xf0,0xdf,0x63,0x6c,0x7f,0xd8,
	0xd2,0xf6,0x9e,0xf3,0x5e,0x76,0xe7,0xb4,0xbd,0xbb,0x95,0x89,0xf2,0x0a,0xd4,0x4e,
	0x73,0xbd,0x91,0x7e,0x46,0x10,0x3d,0x27,0x49,0x42,0x74,0x89,0xc4,0xe8,0xaa,0xa3,
	0xa7,0x40,0x77,0x85,0xa2,0x7f,0x46,0x26,0xcc,0xc6,0xc0,0xcb,0xc3,0xf2,0xb8,0x81,
	0x21,0xa3,0xbb,0x68,0xf3,0xe2,0xe5,0x7e,0xf4,0x7c,0x71,0x07,0xeb,0xc1,0x0a,0xf5,
	0xdc,0x03,0x8c,0x51,0x0b,0xe9,0xc7,0x13,0x73,0xc1,0x34,0x9e,0xab,0xd2,0x8e,0x66,
	0x58,0x11,0xa5,0x74,0x41,0xcb,0xd2,0xd9,0xe4,0x74,0x80,0xf0,0x89,0xcb,0x45,0x98,
	0x96,0xd7,0xdb,0x08,0x15,0xa5,0x98,0x44,0x6c,0xe2,0x23,0x78,0x56,0x93,0xbc,0x12,
	0x2a,0x85,0x4c,0xc2,0x9f,0xd1,0x59,0x17,0xa1,0x16,0x10,0x25,0xfa,0xe7,0xbd,0x14,
	0x1a,0x56,0xf4,0x4e,0x39,0x6f,0xf5,0x63,0xa2,0x56,0xc5,0x0b,0x7c,0x9f,0xd6,0xf0,
	0xb0,0x68,0x15,0x1c,0x6b,0x36,0x71,0x71,0xf8,0x39,0x83,0x76,0x23,0x54,0xf7,0x55,
	0xbc,0x16,0xe3,0x0c,0xbc,0x21,0x8b,0xde,0x6d,0xe9,0xeb,0x94,0x3d,0x54,0x40,0xc3,
	0xd3,0x20,0xb0,0xaf,0x96,0xbb,0xe7,0xc3,0xb8,0x9d,0xfb,0xee,0xdc,0x9b,0x71,0x53,
	0x83,0x0d,0x9a,0x9f,0xa6,0xb3,0xd2,0x16,0xac,0xea,0xc8,0x80,0x1d,0x8d,0x24,0x24,
	0x3c,0x82,0x91,0x46,0x3c,0x49,0x72,0x90,0xba,0x69,0x8f,0xba,0x7a,0x30,0xdd,0xf6,
	0xa6,0xf1,0x3d,0x68,0xe5,0x37,0xed,0x1a,0x43,0x52,0x8f,0x19,0xd7,0x1a,0x52,0x52,
	0x8c,0xd8,0x0f,0xb2,0x64,0x28,0xa5,0xab,0xa7,0x0e,0x04,0xa2,0x67,0xaa,0x65,0x0b,
	0x66,0x6f,0xf6,0x96,0xb2,0x90,0x5f,0xa5,0xec,0xae,0x9b,0xb3,0xb9,0x84,0x53,0x6d,
	0xbc,0x5f,0xbe,0x64,0x70,0x36,0xe6,0xee,0x1d,0xd1,0x7e,0xb5,0x8a,0xe4,0xa1,0x37,
	0xe8,0xdb,0x3e,0x8f,0xc2,0xfd,0xea,0xe9,0xe3,0x5f,0x74,0xb4,0x94,0xfc,0xa0,0x20,
	0x6e,0x8f,0xd3,0x96,0x14,0x6b,0xfb,0xf5,0x6a,0xd8,0x12,0x26,0x36,0x95,0x5f,0x1c,
	0x75,0x16,0xad,0x18,0xe5,0x0c,0x9a,0xc5,0x37,0x74,0xec,0x0c,0xc3,0x67,0x04,0x4f,
	0xd6,0xda,0xa6,0x80,0x96,0xd1,0x26,0x37,0x13,0xbd,0x7a,0x0f,0x21,0x89,0x2b,0x33,
	0xb3,0x18,0x9b,0x3b,0x37,0xfd,0xe4,0x51,0x17,0x02,0x03,0x01,0x00,0x01 };


COPMSession::COPMSession(IOPMVideoOutput* pOPMVideoOutput, HRESULT* phr)
	: m_spOPMVideoOutput(pOPMVideoOutput)
	, m_ulStatusSequence(0)
{
	HRESULT hr = S_OK;
	if (pOPMVideoOutput == nullptr)
	{
		if (phr != nullptr)
			*phr = E_POINTER;
		return;
	}

	OPM_RANDOM_NUMBER random;   // Random number from driver.
	ZeroMemory(&random, sizeof(random));

	BYTE *pbCertificate = NULL; // Pointer to a buffer to hold the certificate.
	ULONG cbCertificate = 0;    // Size of the certificate in bytes.

	// Get the driver's certificate chain + random number
	hr = pOPMVideoOutput->StartInitialization(&random, &pbCertificate, &cbCertificate);

	if (FAILED(hr))
	{
		LOG_ERROR(L"[OPM] Failed to start OPM video output initialization {hr: 0X%08X}.\n", hr);
		goto done;
	}

	// Parameter generation for initialization
	OPM_ENCRYPTED_INITIALIZATION_PARAMETERS initParam;
	ZeroMemory(&initParam, sizeof(initParam));
	// initParam[ 0..15]	128bit random Number (Driver generated: StartInitialization () value returned)
	// initParam[16..31]	128bit AES session
	// initParam[32..35]	Sequence number (OPM status)
	// initParam[36..39]	Sequence number (OPM command)
	LPBYTE pInitParam = (LPBYTE)&initParam;
	memcpy(pInitParam, &random, sizeof(random));
	pInitParam += sizeof(random);

	hr = CryptUtil::GenerateRandom(pInitParam, AES_KEYSIZE_128 + sizeof(ULONG) + sizeof(ULONG));
	if (FAILED(hr))
	{
		LOG_ERROR(L"[OPM] CryptUtil::GenerateRandom() failed. hr = 0x%08x\n", hr);
		goto done;
	}

	// Save session key to use for encryption during status request
	// initParam will be encrypted, so you can copy the text separately.
	BYTE bAESSessionKey[AES_KEYSIZE_128];
	memcpy(bAESSessionKey, pInitParam, sizeof(bAESSessionKey));
	pInitParam += sizeof(bAESSessionKey);

	// OPM save Status request Sequence number
	// Use it to check the output destination
	m_ulStatusSequence = *((ULONG*)pInitParam);
	pInitParam += sizeof(ULONG);

	// OPM Command execution Sequence number
	ULONG ulCommandSequence = 0;
	ulCommandSequence = *((ULONG*)pInitParam);
	pInitParam += sizeof(ULONG);

	// Encrypted with RSAES-OAEP using the driver's public key
	hr = CryptUtil::EncryptRSAESOAEPWithPublicKey(
		pbCertificate,					// Certificate chain
		cbCertificate,					// Certificate Chain Size
		(LPBYTE)&initParam,				// Encrypted buffer
		sizeof(initParam),				// Encryption Target buffer size
		pInitParam - (LPBYTE)&initParam,// Data length to be encrypted
		PETRUSTED_ROOTCERT_PUBKEY,
		sizeof(PETRUSTED_ROOTCERT_PUBKEY)
	);
	if (FAILED(hr))
	{
		LOG_ERROR(L"[OPM] Failed to encrypt with RSAES-OAEP using the driver's public key. hr = 0x%08x\n", hr);
		goto done;
	}

	hr = pOPMVideoOutput->FinishInitialization(&initParam);
	if (FAILED(hr))
	{
		wprintf(L"[OPM] pOPMVideoOutput->FinishInitialization() failed. hr = 0x%08x\n", hr);
		goto done;
	}

done:
	if (phr)
		*phr = hr;
}


COPMSession::~COPMSession()
{
	m_spOPMVideoOutput = nullptr;
}

HRESULT COPMSession::_StatusRequest(GUID guidInformation, OPM_REQUESTED_INFORMATION& StatusOutput, uint8_t* pParams, size_t cbParams)
{
	HRESULT hr = S_OK;
	OPM_OMAC rgbSignature = { 0 };
	OPM_GET_INFO_PARAMETERS StatusInput;

	//--------------------------------------------------------------------
	// Prepare the status request structure.
	//--------------------------------------------------------------------

	ZeroMemory(&StatusInput, sizeof(StatusInput));
	ZeroMemory(&StatusOutput, sizeof(StatusOutput));

	if (pParams != NULL && cbParams > 0)
	{
		if (cbParams > sizeof(StatusInput.abParameters))
			return E_INVALIDARG;

		memcpy(StatusInput.abParameters, pParams, cbParams);
		StatusInput.cbParametersSize = cbParams;
	}

	hr = BCryptGenRandom(
		NULL,
		(BYTE*)&(StatusInput.rnRandomNumber),
		OPM_128_BIT_RANDOM_NUMBER_SIZE,
		BCRYPT_USE_SYSTEM_PREFERRED_RNG
	);

	if (FAILED(hr))
	{
		LOG_WARNING(L"[OPM] Failed to generate random buffer {hr: 0X%08X}.\n", hr);
		goto done;
	}

	StatusInput.guidInformation = guidInformation;			// Request GUID.
	StatusInput.ulSequenceNumber = m_ulStatusSequence;		// Sequence number.

	//  Sign the request structure, not including the OMAC field.
	hr = CryptUtil::ComputeOMAC1(
		m_keySession.abRandomNumber,                        // Session key.
		(BYTE*)&StatusInput + OPM_OMAC_SIZE,                // Data
		sizeof(OPM_GET_INFO_PARAMETERS) - OPM_OMAC_SIZE,    // Size
		StatusInput.omac.abOMAC                             // Receives the OMAC
	);

	if (FAILED(hr))
	{
		LOG_WARNING(L"[OPM] Failed to compute OMAC-1 {hr: 0X%08X}.\n", hr);
		goto done;
	}

	//  Send the status request.
	hr = m_spOPMVideoOutput->GetInformation(&StatusInput, &StatusOutput);

	if (FAILED(hr))
	{
		LOG_WARNING(L"[OPM] Failed to call GetInformation with OPM video output interface {hr: 0X%08X}.\n", hr);
		goto done;
	}

	//--------------------------------------------------------------------
	// Verify the signature.
	//--------------------------------------------------------------------

	// Calculate our own signature.
	hr = CryptUtil::ComputeOMAC1(
		m_keySession.abRandomNumber,
		(BYTE*)&StatusOutput + OPM_OMAC_SIZE,
		sizeof(OPM_REQUESTED_INFORMATION) - OPM_OMAC_SIZE,
		rgbSignature.abOMAC
	);

	if (FAILED(hr))
	{
		LOG_WARNING(L"[OPM] Failed to calculate the OMAC-1 value based on the Status output from OPM {hr: 0X%08X}.\n", hr);
		goto done;
	}

	if (memcmp(StatusOutput.omac.abOMAC, rgbSignature.abOMAC, OPM_OMAC_SIZE))
	{
		// The signature does not match.
		LOG_WARNING(L"[OPM] The status output of OPM failed to verify the OMAC-1 signature.\n");
		hr = E_FAIL;
		goto done;
	}

	// Update the sequence number.
	m_ulStatusSequence++;

	// Verify rnRandomNumber between input status and output status
	if (StatusOutput.cbRequestedInformationSize < sizeof(OPM_RANDOM_NUMBER))
	{
		LOG_OUTPUT(L"[OPM] The size of requested information size should be not less than %zu.\n", sizeof(OPM_RANDOM_NUMBER));
		hr = E_UNEXPECTED;
		goto done;
	}

	//  Verify the random number.
	if (0 != memcmp(StatusOutput.abRequestedInformation, (BYTE*)&StatusInput.rnRandomNumber, sizeof(OPM_RANDOM_NUMBER)))
	{
		LOG_OUTPUT(L"[OPM] The input random number is not equal to the output random number.\n");
		hr = E_UNEXPECTED;
		goto done;
	}

done:
	return hr;
}

HRESULT COPMSession::GetCurrentHDCPSRMVersion(ULONG& HDCPSRMVer, ULONG* pulStatusFlags)
{
	HRESULT hr = S_OK;

	ULONG ulStatusFlags = 0;
	OPM_REQUESTED_INFORMATION StatusOutput;
	hr = _StatusRequest(OPM_GET_CURRENT_HDCP_SRM_VERSION, StatusOutput);
	if (FAILED(hr))
		return hr;

	OPM_STANDARD_INFORMATION StatusInfo;
	ZeroMemory(&StatusInfo, sizeof(StatusInfo));

	ULONG cbLen = (sizeof(OPM_STANDARD_INFORMATION), StatusOutput.cbRequestedInformationSize);

	if (cbLen != 0)
	{
		// Copy the response into the array.
		CopyMemory((BYTE*)&StatusInfo, StatusOutput.abRequestedInformation, cbLen);
	}

	AMP_SAFEASSIGN(pulStatusFlags, StatusInfo.ulStatusFlags);
	HDCPSRMVer = StatusInfo.ulInformation;

	// Verify the status of the OPM session.
	if (StatusInfo.ulStatusFlags != OPM_STATUS_NORMAL)
	{
		// Abnormal status
		wchar_t szStatusDesc[1024];
		GetFlagsDescW(StatusInfo.ulStatusFlags, OPM_STATUS_flag_names, _countof(OPM_STATUS_flag_names), szStatusDesc, _countof(szStatusDesc), L"OPM_STATUS_NORMAL");
		LOG_WARNING(L"[OPM] OPM session status: %s, it is abnormal.\n", szStatusDesc);
		return E_FAIL;
	}

	return hr;
}

HRESULT COPMSession::GetConnectedHDCPDeviceInformation(ULONG& ulHDCPFlags, OPM_HDCP_KEY_SELECTION_VECTOR& HDCP_Key_Selection_Vector, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetACPAndCGMSASignaling(OPM_ACP_AND_CGMSA_SIGNALING& signaling)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetConnectorType(ULONG& ulConnectorType, ULONG* pulStatusFlags)
{
	HRESULT hr = S_OK;

	ULONG ulStatusFlags = 0;
	OPM_REQUESTED_INFORMATION StatusOutput;
	hr = _StatusRequest(OPM_GET_CONNECTOR_TYPE, StatusOutput);
	if (FAILED(hr))
		return hr;

	OPM_STANDARD_INFORMATION StatusInfo;
	ZeroMemory(&StatusInfo, sizeof(StatusInfo));

	ULONG cbLen = (sizeof(OPM_STANDARD_INFORMATION), StatusOutput.cbRequestedInformationSize);

	if (cbLen != 0)
	{
		// Copy the response into the array.
		CopyMemory((BYTE*)&StatusInfo, StatusOutput.abRequestedInformation, cbLen);
	}

	AMP_SAFEASSIGN(pulStatusFlags, StatusInfo.ulStatusFlags);
	ulConnectorType = StatusInfo.ulInformation;

	// Verify the status of the OPM session.
	if (StatusInfo.ulStatusFlags != OPM_STATUS_NORMAL)
	{
		// Abnormal status
		wchar_t szStatusDesc[1024];
		GetFlagsDescW(StatusInfo.ulStatusFlags, OPM_STATUS_flag_names, _countof(OPM_STATUS_flag_names), szStatusDesc, _countof(szStatusDesc), L"OPM_STATUS_NORMAL");
		LOG_WARNING(L"[OPM] OPM session status: %s, it is abnormal.\n", szStatusDesc);
		return E_FAIL;
	}

	return hr;
}

HRESULT COPMSession::GetSupportedProtectionTypes(ULONG& ulProtectionTypes, ULONG* pulStatusFlags)
{
	HRESULT hr = S_OK;

	ULONG ulStatusFlags = 0;
	OPM_REQUESTED_INFORMATION StatusOutput;
	hr = _StatusRequest(OPM_GET_SUPPORTED_PROTECTION_TYPES, StatusOutput);
	if (FAILED(hr))
		return hr;

	OPM_STANDARD_INFORMATION StatusInfo;
	ZeroMemory(&StatusInfo, sizeof(StatusInfo));

	ULONG cbLen = (sizeof(OPM_STANDARD_INFORMATION), StatusOutput.cbRequestedInformationSize);

	if (cbLen != 0)
	{
		// Copy the response into the array.
		CopyMemory((BYTE*)&StatusInfo, StatusOutput.abRequestedInformation, cbLen);
	}

	AMP_SAFEASSIGN(pulStatusFlags, StatusInfo.ulStatusFlags);
	ulProtectionTypes = StatusInfo.ulInformation;

	// Verify the status of the OPM session.
	if (StatusInfo.ulStatusFlags != OPM_STATUS_NORMAL)
	{
		// Abnormal status
		wchar_t szStatusDesc[1024];
		GetFlagsDescW(StatusInfo.ulStatusFlags, OPM_STATUS_flag_names, _countof(OPM_STATUS_flag_names), szStatusDesc, _countof(szStatusDesc), L"OPM_STATUS_NORMAL");
		LOG_WARNING(L"[OPM] OPM session status: %s, it is abnormal.\n", szStatusDesc);
		return E_FAIL;
	}

	return hr;
}

HRESULT COPMSession::GetVirtualProtectionLevel(ULONG protection_type, ULONG& protection_level, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetActualProtectionLevel(ULONG protection_type, ULONG& protection_level, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetActualOutputFormat(OPM_ACTUAL_OUTPUT_FORMAT& output_format)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetAdaptorBusType(ULONG& ulBusType, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetOutputID(UINT64& ullOutputID, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetDVICharacteristics(ULONG& ulCharacteristics, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetCodecInfo(DWORD& Merit, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetOutputHardwareProtectionSupport(OPM_OUTPUT_HARDWARE_PROTECTION& eSupportState, ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::GetProtectionLevel(ULONG* ulStatusFlags)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::SetProtectionLevel(ULONG ulProtectionType, ULONG ulProtectionLevel)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::SetHDCPSRM(ULONG ulSRMVersion, uint8_t* pSRMData, size_t cbSRMData)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::SetACPAndCGMSASignaling(OPM_SET_ACP_AND_CGMSA_SIGNALING_PARAMETERS params)
{
	return E_NOTIMPL;
}

HRESULT COPMSession::SetProtectionLevelAccordingToCSSDVD(ULONG ulProtectionType, ULONG ulProtectionLevel)
{
	return E_NOTIMPL;
}

